package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Cart;
import com.example.demo.proxy.CustomizeCartServiceProxy;


@RestController
@Scope("request")
public class CustomizeCartController {
	
	@Autowired
	public CustomizeCartServiceProxy service;
	
	 @PutMapping(value ="/cart")
	    public Cart updateCart(@RequestBody Cart cart) {
	        return service.updateCart(cart);
	    }

	    @DeleteMapping("/cart/id/{id}")
	    public boolean deleteCartById(@PathVariable("id") int id) {
	        return service.deleteCartById(id);
	    }
	
	
	
}
