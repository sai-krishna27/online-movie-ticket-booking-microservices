package com.example.demo.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.entity.Cart;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name="cart-service")
public interface CustomizeCartServiceProxy

{
	@Retry(name="cart-service")
	@CircuitBreaker(name="cart-service",fallbackMethod="fallbackUpdateCart")
	@PutMapping(value="/cart")
	public Cart updateCart(@RequestBody Cart cart);
	
	
	@Retry(name="cart-service")
	@CircuitBreaker(name="cart-service",fallbackMethod="fallBackMethoddeleteCartById")
	@DeleteMapping("/cart/id/{id}")
	public boolean deleteCartById(@PathVariable("id") int id);
	
	
	 public default Cart fallbackUpdateCart(@RequestBody Cart cart, Throwable cause) {
	        System.out.println("Exception raised with message:===> "+cause.getMessage());
	        return new Cart(0,null,0,0,null);
	    }
	
	
	public default boolean fallBackMethoddeleteCartById(int id, Throwable cause) {
        System.out.println("Exception raised with message: ===> " + cause.getMessage());
        return false;
    }
	

}
