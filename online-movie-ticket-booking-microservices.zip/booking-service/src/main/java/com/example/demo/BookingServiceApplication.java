package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;

import com.example.demo.Entity.*;
import com.example.demo.repo.*;

import brave.sampler.Sampler;

@EnableEurekaClient
@SpringBootApplication
public class BookingServiceApplication implements CommandLineRunner {

	@Bean
	public Sampler alwaysSampler() {
		return Sampler.ALWAYS_SAMPLE;
	}
	
	public static void main(String[] args) {
		SpringApplication.run(BookingServiceApplication.class, args);
	}
	
	
	@Autowired
	public OrderRepo orderRepo;
	

	@Override
	public void run(String... args) throws Exception {
		
		orderRepo.save(new Order("john wick 4",2,500f,"john@gmail.com","06-09-2023","15:05:00",568421));
		orderRepo.save(new Order("john wick 3",2,500f,"tom@gmail.com","06-09-2023","15:05:00",568871));
		
		
	}

}
