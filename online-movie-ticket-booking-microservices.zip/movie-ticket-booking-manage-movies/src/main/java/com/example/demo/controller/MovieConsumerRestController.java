package com.example.demo.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.Movie;
import com.example.demo.proxy.MovieServiceProxy;

@RestController
@Scope("request")
public class MovieConsumerRestController {
	@Autowired
	private MovieServiceProxy movieServiceProxy;
	private Logger log=LoggerFactory.getLogger(MovieConsumerRestController.class);
	

    
    @PutMapping(value = "/put-updateMovie")
    public Movie updateMovie(@RequestBody Movie movie) {
        log.debug("In updateMovie with Movie: " + movie);
        Movie updatedMovie = movieServiceProxy.updateMovie(movie);
        log.debug("In updateMovie with return value Movie: " + updatedMovie);
        return updatedMovie;
    }

    @GetMapping("/get-movie/{id}")
    public Movie getMovieById(@PathVariable("id") int id) {
        log.debug("In getMovieById with Id: " + id);
        Movie movie = movieServiceProxy.getMovieById(id);
        log.debug("In getMovieById with return value Movie: " + movie);
        return movie;
    }

    @PostMapping(value = "/post-addMovie")
    public Movie addMovie(@RequestBody Movie movie) {
        log.debug("In addMovie with Movie: " + movie);
        Movie addedMovie = movieServiceProxy.addMovie(movie);
        log.debug("In addMovie with return value Movie: " + addedMovie);
        return addedMovie;
    }

    @DeleteMapping("/delete-deleteMovieById/{id}")
    public boolean deleteMovieById(@PathVariable("id") int id) {
        log.debug("In deleteMovieById with Id: " + id);
        boolean result = movieServiceProxy.deleteMovieById(id);
        log.debug("In deleteMovieById with return value: " + result);
        return result;
    }

    @GetMapping("/get-movies")
    public List<Movie> viewAllMovie() {
        List<Movie> movies = movieServiceProxy.viewAllMovie();
        log.debug("In getAllMovies with return value Movies: " + movies);
        return movies;
    }


}
