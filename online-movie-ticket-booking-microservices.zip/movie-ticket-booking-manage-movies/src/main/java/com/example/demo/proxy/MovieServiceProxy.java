package com.example.demo.proxy;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.Entity.Movie;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("movie-service")
public interface MovieServiceProxy 

{
	
	
	@Retry(name="movie-service")
	@CircuitBreaker(name="movie-service",fallbackMethod="fallBackMethodgetAllMovies")
	@GetMapping("/movies")
	public List<Movie> viewAllMovie() ;
	
	public default List<Movie> fallBackMethodgetAllMovies(Throwable cause)
	{
		System.out.println("Exception raised with message:===> "+cause.getMessage());
		
	
	ArrayList<Movie> movie=new ArrayList<>(); 
	movie.add(new Movie(0,"GameOfThrones","english","IceAndFire","05:45:32",5.0f,250f,
			"https://assets-prd.ignimgs.com/2022/01/14/gameofthrones-allseasons-sq-1642120207458.jpg",
			"drama","enable"));
	return movie;
	}
	
	@Retry(name="movie-service")
	@CircuitBreaker(name="movie-service",fallbackMethod="fallBackMethodgetMovieById")
	@GetMapping("/movie/{id}")
	public Movie getMovieById(@PathVariable("id") int id) ;
	
	public default Movie fallBackMethodgetMovieById(int id,Throwable cause)
	{
		System.out.println("Exception raised with message:===> "+cause.getMessage());
		return new Movie(id,"GameOfThrones","english","IceAndFire","05:45:32",5.0f,250f,
				"https://assets-prd.ignimgs.com/2022/01/14/gameofthrones-allseasons-sq-1642120207458.jpg",
				"drama","enable");
	}
	
	@Retry(name="movie-service")
	@CircuitBreaker(name="movie-service",fallbackMethod="fallBackMethodadddMovie")
	@PostMapping(value = "/addMovie")
	public Movie addMovie(@RequestBody Movie movie) ;
	public default Movie fallBackMethodadddMovie(Throwable cause)
	{
		System.out.println("Exception raised with message:===> "+cause.getMessage());
		return new Movie(0,"GameOfThrones","english","IceAndFire","05:45:32",5.0f,250f,
				"https://assets-prd.ignimgs.com/2022/01/14/gameofthrones-allseasons-sq-1642120207458.jpg",
				"drama","enable");
	}
	
	@Retry(name="movie-service")
	@CircuitBreaker(name="movie-service",fallbackMethod="fallBackMethodupdateMovie")
	@PutMapping(value = "/updateMovie")
	public Movie updateMovie(@RequestBody Movie movie) ;
	public default Movie fallBackMethodupdateMovie(Throwable cause)
	{
		System.out.println("Exception raised with message:===> "+cause.getMessage());
		return new Movie(0,"GameOfThrones","english","IceAndFire","05:45:32",5.0f,250f,
				"https://assets-prd.ignimgs.com/2022/01/14/gameofthrones-allseasons-sq-1642120207458.jpg",
				"drama","enable");
	}
	
	@Retry(name="movie-service")
	@CircuitBreaker(name="movie-service",fallbackMethod="fallBackMethoddeleteMovieById")
	@DeleteMapping("/deleteMovieById/{id}")
	public boolean deleteMovieById(@PathVariable("id") int id);
	public default boolean fallBackMethoddeleteMovieById(int id, Throwable cause) {
        System.out.println("Exception raised with message: ===> " + cause.getMessage());
        return false;
    }
	

	
	

}
