package com.example.demo.Entity;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Movie {


	
	private int mid;

	
	private String mname;
	
	private String mlanguage;

	private String mdescription;
	
	private String mduration;

	private Float mrating;

	private Float mprice;

	private String mimage;

	private String mgerne;

	private String mstatus;

	
	
}