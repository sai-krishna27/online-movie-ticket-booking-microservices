package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.entity.Movie;
import com.example.demo.service.SearchMoviesService;

@RestController
@Scope(value="request")
public class SearchMoviesController {
	
	@Autowired
	public SearchMoviesService service;
	
	
	@GetMapping("/searchMovie/{movie}")
	public List<Movie> serchMovieByKeyword(@PathVariable("movie") String movie) {	
		return service.searchMovie(movie);
	}
	
	@GetMapping("/sortMoviesByGenre")
	public List<Movie> sortByGenre(){
		return service.getSortedMovies();
	}
}
