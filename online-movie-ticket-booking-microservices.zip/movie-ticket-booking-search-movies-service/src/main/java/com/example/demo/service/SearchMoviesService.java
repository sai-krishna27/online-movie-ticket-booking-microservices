package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.demo.entity.Movie;


import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name="movie-service")
public interface SearchMoviesService {
	
	
	@Retry(name="movie-service")
	@CircuitBreaker(name="movie-service",fallbackMethod = "fallBackOfSearchMovie")
	@GetMapping("/searchMovie/{movie}")
	public List<Movie> searchMovie(@PathVariable("movie") String movie) ;
		
	@Retry(name="movie-service")
	@CircuitBreaker(name="movie-service",fallbackMethod = "fallBackOfSortByGenre")
	@GetMapping("/sortMoviesByGerne")
	public List<Movie> getSortedMovies() ;
	
	public default List<Movie> fallBackOfSearchMovie(String movie,Throwable cause) {
		System.out.println("Exception raised is "+cause.getMessage());
		ArrayList<Movie> Movies= new ArrayList<> ();
		Movies.add(new Movie("Restless","French","Crime","01:36:32",4.8f,250f,
				"https://static.wikia.nocookie.net/john-wick8561/images/7/7c/Chapterfour.jpeg/revision/latest?cb=20230523074638",
				"Thriller","disable"));
		return Movies;
	}
	
	public default List<Movie> fallBackOfSortByGenre(Throwable cause) {
		System.out.println("Exception raised is "+cause.getMessage());
		ArrayList<Movie> Movies= new ArrayList<> ();
		Movies.add(new Movie("Oxygen","French","Claustrophobic","01:41:20",4.5f,250f,
				"https://static.wikia.nocookie.net/john-wick8561/images/7/7c/Chapterfour.jpeg/revision/latest?cb=20230523074638",
				"Horror","disable"));
		return Movies;
	}
}
