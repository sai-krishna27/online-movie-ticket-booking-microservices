package com.example.demo.entity;



import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Movie {
	
	public Movie(String mname, String mlanguage, String mdescription, String mduration, Float mrating, Float mprice,
			String mimage, String mgerne, String mstatus) {
		super();
		this.mname = mname;
		this.mlanguage = mlanguage;
		this.mdescription = mdescription;
		this.mduration = mduration;
		this.mrating = mrating;
		this.mprice = mprice;
		this.mimage = mimage;
		this.mgerne = mgerne;
		this.mstatus = mstatus;
	}
	private int mid;
	private String mname;
	private String mlanguage;
	private String mdescription;
	private String mduration;
	private Float mrating;
	private Float mprice;
	private String mimage;
	private String mgerne;
	private String mstatus;

}
