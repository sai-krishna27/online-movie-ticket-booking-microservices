package com.example.demo.proxy;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.Entity.Movie;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient("movie-service")
public interface MovieServiceProxy 

{
	@Retry(name="movie-service")
	@CircuitBreaker(name="movie-service",fallbackMethod="fallBackMethodgetEnabledMovies")
	@GetMapping("/getEnabledMovies")
	public List<Movie> getEnabledMovies() ;
	
	public default List<Movie> fallBackMethodgetEnabledMovies(Throwable cause)
	{
		System.out.println("Exception raised with message:===> "+cause.getMessage());
		ArrayList<Movie> movie=new ArrayList<>(); 
		movie.add(new Movie(0,"no-movies",null,null,null,null,null ,null, null,"no movies available"));
		return movie;
		
	}
}
