package com.example.demo.service;

import java.util.ArrayList;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.entity.Order;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name="booking-service")
public interface ManageBookingService {
	
	
	@Retry(name="booking-service")
	@CircuitBreaker(name="booking-service",fallbackMethod = "fallBackOfGetCustomerOrder")
	@GetMapping("/order/{email}")
	public List<Order> getCustomerOrder(@PathVariable("email")String emailId);
	
	
	@Retry(name="booking-service")
	@CircuitBreaker(name="booking-service",fallbackMethod = "fallBackOfAddOrder")
	@PostMapping("/order")
	public Order addOrder(Order order);
	
	
	public default List<Order> fallBackOfGetCustomerOrder(String emailId,Throwable cause) {
		System.out.println("Exception raised is "+cause.getMessage());
		ArrayList<Order> Orders= new ArrayList<> ();
		Orders.add(new Order("null",0,0f,"null","00-00-0000","00:00:00",0));
		return Orders;
	}
	
	
	public default Order fallBackOfAddOrder(Throwable cause) {
		System.out.println("Exception raised is "+cause.getMessage());
		return new Order("null",0,0f,"null","00-00-0000","00:00:00",0);
	}
	
	
}
