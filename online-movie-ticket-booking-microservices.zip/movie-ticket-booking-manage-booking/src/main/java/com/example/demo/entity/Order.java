package com.example.demo.entity;

import lombok.AllArgsConstructor;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Order {
	
	private int id;
	private String movie;
	private int quantity;
	private float price;
	private String email;
	private String movieData;
	private String movieTime;
	private long transactionId;
	public Order(String movie, int quantity, float price, String email, String movieData, String movieTime,
			long transactionId) {
		super();
		this.movie = movie;
		this.quantity = quantity;
		this.price = price;
		this.email = email;
		this.movieData = movieData;
		this.movieTime = movieTime;
		this.transactionId = transactionId;
	}

}
