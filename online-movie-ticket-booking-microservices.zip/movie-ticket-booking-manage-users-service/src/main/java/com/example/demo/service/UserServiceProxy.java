package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.demo.entity.User;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name="user-service")
public interface UserServiceProxy {
	
	@Retry(name="user-service")
	@CircuitBreaker(name="user-service",fallbackMethod = "fallBackOfGetAllUsers")
	@GetMapping("/users")
	public List<User> getAllUsers();
	
	
	@Retry(name="user-service")
	@CircuitBreaker(name="user-service",fallbackMethod = "fallBackOfDeleteUser")
	@DeleteMapping("/user/{id}")
	public String deleteUser(@PathVariable("id") int id);
	
	

	public default List<User> fallBackOfGetAllUsers(Throwable cause) {
		System.out.println("Exception raised is "+cause.getMessage());
		return new ArrayList<User>();
	}
	
	public default String fallBackOfDeleteUser(int id,Throwable cause) {
		System.out.println("Exception raised is "+cause.getMessage());
		return "user not found";
	}
	

	
	
}
