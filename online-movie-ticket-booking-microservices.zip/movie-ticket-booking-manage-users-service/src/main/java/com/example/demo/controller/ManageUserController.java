package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Order;
import com.example.demo.entity.User;
import com.example.demo.service.CartServiceProxy;
import com.example.demo.service.OrderServiceProxy;
import com.example.demo.service.UserServiceProxy;

@RestController
@Scope(value="request")
public class ManageUserController {
	
	@Autowired
	public UserServiceProxy user;
	
	@Autowired
	public OrderServiceProxy order;
	
	@Autowired
	public CartServiceProxy cart;
	
	@GetMapping("/get-users")
	public List<User> getAllUsers(){
		return user.getAllUsers();
	}
	
	
	@DeleteMapping("/delete-user/{id}")
	public String deleteUser(@PathVariable("id") int id){
		return user.deleteUser(id); 
	}
	
	@GetMapping("/get-order-by-email/{email}")
	public List<Order> getUserOrders(@PathVariable("email") String email ){
		return order.getUserOrders(email);
	}
	
	@DeleteMapping("/delete-order/{email}")
	public String deleteOrdersByEmail(@PathVariable String email) {
		return order.deleteOrdersByEmail(email);
	}
	
	@DeleteMapping("/delete-cart/{email}")
	public Boolean deleteCartByEmail(@PathVariable("email") String email) {
		return cart.deleteCartByEmail(email);
	}
	
	
	
	
}
