package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.demo.entity.Order;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name="booking-service")
public interface OrderServiceProxy {

	@Retry(name="booking-service")
	@CircuitBreaker(name="booking-service",fallbackMethod = "fallBackOfDeleteOrdersByEmail")
	@DeleteMapping("/order/{email}")
	public String deleteOrdersByEmail(@PathVariable String email);
	
	@Retry(name="booking-service")
	@CircuitBreaker(name="booking-service",fallbackMethod = "fallBackOfGetUserOrders")
	@GetMapping("/order/{email}")
	public List<Order> getUserOrders(@PathVariable("email") String email );
	
	public default String fallBackOfDeleteOrdersByEmail(String email,Throwable cause) {
		System.out.println("Exception raised is "+cause.getMessage());
		return "orders not found";
	}
	
	public default List<Order> fallBackOfGetUserOrders(String email,Throwable cause) {
		System.out.println("Exception raised is "+cause.getMessage());
		ArrayList<Order> orders=new ArrayList<>();
		orders.add(new Order(0,"no movie tickets booked",0,0f,email,null,null,0));
		return orders;
	}
}
