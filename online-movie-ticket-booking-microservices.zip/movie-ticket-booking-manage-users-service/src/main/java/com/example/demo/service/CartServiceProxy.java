package com.example.demo.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name="cart-service")
public interface CartServiceProxy {


	@Retry(name="cart-service")
	@CircuitBreaker(name="cart-service",fallbackMethod = "fallBackOfDeleteCartByEmail")
	@DeleteMapping("/cart/email/{email}")
	public boolean deleteCartByEmail(@PathVariable("email") String email);
	
	public default boolean fallBackOfDeleteCartByEmail(String email,Throwable cause) {
		System.out.println("Exception raised is "+cause.getMessage());
		return false;
	}
}
