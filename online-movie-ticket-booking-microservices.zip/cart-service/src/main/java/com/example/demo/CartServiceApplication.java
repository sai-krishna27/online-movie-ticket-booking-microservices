package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;

import com.example.demo.Entity.*;
import com.example.demo.repo.*;

import brave.sampler.Sampler;

@EnableEurekaClient
@SpringBootApplication
public class CartServiceApplication implements CommandLineRunner {

	@Bean
	public Sampler alwaysSampler() {
		return Sampler.ALWAYS_SAMPLE;
	}
	
	public static void main(String[] args) {
		SpringApplication.run(CartServiceApplication.class, args);
	}
	
	
	@Autowired
	public CartRepo cartRepo;

	@Override
	public void run(String... args) throws Exception {
		
		cartRepo.save(new Cart("john@gmail.com",2,500f,"john wick 4"));
		cartRepo.save(new Cart("tom@gmail.com",2,500f,"john wick 3"));
		
		
	}

}
