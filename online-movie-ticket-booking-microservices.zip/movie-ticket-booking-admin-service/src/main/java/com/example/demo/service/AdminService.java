package com.example.demo.service;



import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.entity.Admin;


import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name="admin-service")
public interface AdminService {
	
	
	@Retry(name="admin-service")
	@CircuitBreaker(name="admin-service",fallbackMethod = "fallBackOfGetAdminByEmail")
	@GetMapping("/admin/{email}")
	public Admin getAdminByEmail(@PathVariable("email") String email);
	
	
	@Retry(name="admin-service")
	@CircuitBreaker(name="admin-service",fallbackMethod = "fallBackOfAddAdmin")
	@PostMapping("/admin")
	public Admin addAdmin(@RequestBody Admin admin);
	
	public default Admin fallBackOfGetAdminByEmail(String email,Throwable cause) {
		System.out.println("Exception raised is "+cause.getMessage());
		return new Admin("admin doen't exist",null,null);
	}
	

	
	public default Admin fallBackOfAddAdmin(Throwable cause) {
		System.out.println("Exception raised is "+cause.getMessage());
		return new Admin("email already exists",null,null);
	}
	
	
}
