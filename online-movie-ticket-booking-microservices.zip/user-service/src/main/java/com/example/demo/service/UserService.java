package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.User;
import com.example.demo.repo.UserRepo;

@Service
public class UserService {
	
	@Autowired
	public UserRepo userRepo;
	
	public List<User> getAllUsers(){
		return userRepo.findAll();
	}
	
	public User getUserById(int id) {
		try {
		return userRepo.findById(id).get();
		}
		catch(Exception e) {
			return new User();
		}
	}
	
	public User getUserByEmail(String email) {
		return userRepo.getUserByEmail(email);
	}
	
	public User addUser(User user) {
		return userRepo.save(user);
	}
	
	public String deleteUser(int id) {
		try {
		userRepo.deleteById(id);
		return "user is removed from the database";
		}
		catch(Exception e) {
			return "user not found";
		}
	}
	
	public User updateUser(User user) {
		return userRepo.save(user);
	}

}
