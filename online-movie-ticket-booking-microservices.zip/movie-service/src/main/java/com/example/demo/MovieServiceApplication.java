package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;

import com.example.demo.Entity.*;
import com.example.demo.repo.*;

import brave.sampler.Sampler;

@EnableEurekaClient
@SpringBootApplication
public class MovieServiceApplication implements CommandLineRunner {

	@Bean
	public Sampler alwaysSampler() {
		return Sampler.ALWAYS_SAMPLE;
	}
	
	public static void main(String[] args) {
		SpringApplication.run(MovieServiceApplication.class, args);
	}
	
	@Autowired
	public MovieRepo movieRepo;

	@Override
	public void run(String... args) throws Exception {
		
		movieRepo.save(new Movie("john wich 4","english","gangster","02:45:32",5.0f,250f,
				"https://static.wikia.nocookie.net/john-wick8561/images/7/7c/Chapterfour.jpeg/revision/latest?cb=20230523074638",
				"action","enable"));
		movieRepo.save(new Movie("john wich 3","english","gangster","02:45:32",5.0f,250f,
				"https://images-na.ssl-images-amazon.com/images/S/pv-target-images/459543e33775972b85d72b253740f3c36c809ce05aaa19b6c1227231877e60e1._RI_TTW_.jpg",
				"action","enable"));
		
	}

}
