package com.example.demo.service;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.entity.User;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name="user-service")
public interface UserService {
	
	@Retry(name="user-service")
	@CircuitBreaker(name="user-service",fallbackMethod = "fallBackOfAddUser")
	@PostMapping("/user")
	public User addUser(User user);
	
	@Retry(name="user-service")
	@CircuitBreaker(name="user-service",fallbackMethod = "fallBackOfGetUserByEmail")
	@GetMapping("/userByEmail/{email}")
	public User getUserByEmail(@PathVariable("email") String email);
	
	
	public default User fallBackOfGetUserByEmail(String email,Throwable cause) {
		System.out.println("Exception raised is "+cause.getMessage());
		return new User(0,null,null,null,null,null);
	}
	

	public default User fallBackOfAddUser(Throwable cause) {
		System.out.println("Exception raised is "+cause.getMessage());
		return new User(0,null,null,null,null,null);
	}
	
	
}
