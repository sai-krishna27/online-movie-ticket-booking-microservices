package com.example.demo.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.User;
import com.example.demo.service.UpdateUserProxy;

@RestController
@Scope("request")
public class UserController {
	@Autowired
	private UpdateUserProxy userDao;
	private Logger log=LoggerFactory.getLogger(UserController.class);
	

	@PutMapping("/put-updateUser")
    public User updateUser(@RequestBody User user) {
        log.debug("In updateUser with User: " + user);
        User updatedUser = userDao.updateUser(user);
        log.debug("In updateUser with return value User: " + updatedUser);
        return updatedUser;
    }
	
	@GetMapping("/user-by-email/{email}")
	public User getUserByEmal(@PathVariable("email") String email){
		return userDao.getUserByEmail(email);
	}
}