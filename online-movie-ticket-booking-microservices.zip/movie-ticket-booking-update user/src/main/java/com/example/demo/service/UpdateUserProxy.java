package com.example.demo.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.Entity.User;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name = "user-service")
public interface UpdateUserProxy {

	@Retry(name = "user-service")
	@CircuitBreaker(name = "user-service", fallbackMethod = "fallbackForUpdateUser")
	@PutMapping("/updateUser")
	public User updateUser(@RequestBody User user);
	
	@Retry(name = "user-service")
	@CircuitBreaker(name = "user-service", fallbackMethod = "fallBackOfGetUserByEmail")
	@GetMapping("/userByEmail/{email}")
	public User getUserByEmail(@PathVariable("email") String email);
	
	
	public default User fallbackForUpdateUser(User user,Throwable cause)
	{
		System.out.println("Exception raised with message:===> "+cause.getMessage());
		return new User(0,"user not exists to update",null,null,null,null);
	}
	
	public default User fallBackOfGetUserByEmail(String email,Throwable cause) {
		System.out.println("Exception raised with message:===> "+cause.getMessage());
		return new User(0,"no user found",email,null,null,null);
	}
}






