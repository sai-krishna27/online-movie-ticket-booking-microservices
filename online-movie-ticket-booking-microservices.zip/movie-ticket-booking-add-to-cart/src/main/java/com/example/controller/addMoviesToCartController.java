package com.example.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.Entity.Cart;
import com.example.service.addMoviesToCartService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;

@RestController
@Scope(value="request")
public class addMoviesToCartController {
	
	@Autowired
	public addMoviesToCartService service;
	@PostMapping("/cart")
	public Cart addCart(@RequestBody Cart cart) {
		return service.addCart(cart);
	}
}
