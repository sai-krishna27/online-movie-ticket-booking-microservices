package com.example.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.Entity.Cart;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;
@FeignClient(name="cart-service")
public interface addMoviesToCartService {
	@Retry(name="cart-service")
	@CircuitBreaker(name="cart-service",fallbackMethod = "fallBackOfaddMoviesToCart")
	@PostMapping("/cart")
	public Cart addCart(Cart cart);
	
	public default Cart fallBackOfaddMoviesToCart(Cart cart,Throwable cause) {
		System.out.println("Exception raised is "+cause.getMessage());
		return new Cart(0,null,0,0,null);
	}
}
